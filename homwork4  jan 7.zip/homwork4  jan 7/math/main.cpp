#include <iostream>

#include "math.h"

int main() {
    int integers = 5;
    return 0;
}