#ifndef MATH_H
#define MATH_H

int fibonacci(int integer);
bool isPrime(int integer);
bool isPowerOfTwo(int n);
#endif 