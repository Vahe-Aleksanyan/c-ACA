Homework:
Write a simple math library with 3-4 functions (Fibonacci, isPrime, is power of two, number of 1s in binary representation) with unit tests